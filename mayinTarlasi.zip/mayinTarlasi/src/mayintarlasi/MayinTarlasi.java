
package mayintarlasi;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author erhan
 */
public class MayinTarlasi {


    public static void main(String[] args) {
        
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();
        System.out.println("MAYIN TARLASI OYUNUNA HOŞGELDİNİZ!!");
        System.out.println("İlk olarak sizi tanıyalım.. İsminiz ??");
        String isim = scn.nextLine();
        System.out.println("Hoşgeldin aramıza "+isim+" !");
        System.out.println("Kendi şansın için 5 üzerinden kaç puan verirdin?");
        int sans = scn.nextInt();
        if(sans == 0||sans==1){
            System.out.println("Hadi ya o kadar şanssız mısın..");
            System.out.println("Bence sen en iyisi Birinci seviye zorluktan başla :))");
        }else if(sans == 2|| sans==3){
            System.out.println("Emin ol daha kötülerini gördüm "+isim+"!");
            System.out.println("Bence sen ikinci seviye zorluğun üstesinden gelebilirsin :))");
        }
        else if(sans >= 4){
            System.out.println("İşte aradığımız isim sen oldun "+isim+" !");
            System.out.println("Bence sen varya en zor seviye olan 3. seviyenin bile üstesinden gelebileceğine eminim!");
        }
        else{
            System.out.println("Yok canım o kadar da değilsindir "+isim+ "cim :))");
            System.out.println("Bence sen başlangıç düzeyinden başlasan şansın açılıcaktır eminim :)");
        }
        System.out.println("Geldik seçimine hangi seviyede oynamak istersin :))");
        System.out.println("[1]Başlangıç (3x3)\n"
                          +"[2]Orta Seviye (5x5)\n"
                          +"[3]Uzman (10x10)");
        int seviye = scn.nextInt();
        
        int sayi = 0;
        if(seviye == 1){
            sayi = 3;
        }else if(seviye == 2){
            sayi = 5;
        }else if(seviye == 3){
            sayi = 10;
        }
        System.out.println("Oyun tarlan hazırlanıyor...");
        int oyunTarlasi[][] =new int[sayi][sayi];
       for(int i=0;i<sayi;i++){
           for(int j=0;j<sayi;j++){
               oyunTarlasi[i][j]=rnd.nextInt(2);
           }
       }
       //oluşturulan oyun tarlası
       /* for(int i=0;i<sayi;i++){
           for(int j=0;j<sayi;j++){
               System.out.print(oyunTarlasi[i][j]);
           }
         System.out.println("");  
     } */
     
     //oyun vakti
        System.out.println("Tarla hazırlandı..");
        System.out.println("Oyunu kazanmak için alman gereken puan hesaplanıyor..");
    int bombaSayisi = 0;
    int puan = 0;
        System.out.println("");
        for(int i=0;i<sayi;i++){
           for(int j=0;j<sayi;j++){
               if(oyunTarlasi[i][j]==0){
                   bombaSayisi++;};
           }
        }
        int bitişPuanı = (sayi*sayi)- bombaSayisi;
        System.out.println("Toplam kazanman gereken puan hesaplandı ! = "+bitişPuanı);
        System.out.println("Unutma ki her boş arazi sana 1 puan getiricek "); 
        while(bombaSayisi>0){
            System.out.println("Hangi satırı kontrol ediceksin ?");
            int satır = scn.nextInt();
            System.out.println("Hangi sütunu kontrol ediceksin ?");
            int sütun = scn.nextInt();
            if(satır<sayi+1&&sütun<sayi+1){
            if(oyunTarlasi[satır-1][sütun-1]!=0){
                System.out.println("Harika!! Burası boşmuş :)) ");
                puan+=1;
                System.out.println("Yeni puanın = "+puan);
                System.out.println("-----------------------------------------");
                if(puan==bitişPuanı){
                    System.out.println("Tebrikler!! Çok iyiydin oyunu kazandınız");
                    System.out.println("İşte üstesinden gelmiş olduğun o tarla !!");
                    for(int i=0;i<sayi;i++){
                        for(int j=0;j<sayi;j++){
                        System.out.print(oyunTarlasi[i][j]);
                        }
                        System.out.println("");  
                        } 
                    break;
                }
            }else{
                bombaSayisi-=1;
                System.out.println("Kalan bomba sayisi = "+bombaSayisi);
                System.out.println("-----------------------------------------");
                if(bombaSayisi==0){
                    System.out.println("Üzgünüm kaybettin fakat bir sonraki oyundan yapabilceğinden eminim :)) Bol Şanslar!");
                    System.out.println("Gitmeden önce nerelerde mayın varmış görmen için haritayı bir gösterelim :))");
                    System.out.println("Unutma '0' lar bomba!!");
                    for(int i=0;i<sayi;i++){
                        for(int j=0;j<sayi;j++){
                        System.out.print(oyunTarlasi[i][j]+" ");
                        }
                        System.out.println("");  
                        } 
                }
            }
        }else{
                System.out.println("Lütfen oyun tarlası içindeki alanlardan seçim yap "+isim+". Daha yüksek değer girme :))");
            }
    
    }
    
}
}